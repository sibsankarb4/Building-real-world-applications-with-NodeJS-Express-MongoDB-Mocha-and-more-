module.exports.add = (a, b) => a + b;

module.exports.square = (x) => x * x;
