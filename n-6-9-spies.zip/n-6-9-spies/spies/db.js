module.exports.saveUser = (user) => {
  console.log('Saving the user', user);
};
